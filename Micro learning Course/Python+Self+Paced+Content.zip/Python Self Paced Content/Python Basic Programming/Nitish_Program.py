# Python Console - Script Window


print("Hello World")


